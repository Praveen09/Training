﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stack
{
    public class stacck
    {
        public int[] sal = new int[5];
        public int size = 5;
        public int top = -1;
        public void push()
        {
            int p;
            Console.WriteLine("Enter  a number \n");
            p = Convert.ToInt16(Console.ReadLine());
            if (top < size - 1)
            {
                top++;
                sal[top] = p;
                Console.WriteLine("Added");
            }
            else Console.WriteLine("Overflow");
        }
        public void pop()
        {
            if (top >= 0)
            {
                Console.WriteLine("{0} is popped out", sal[top]);
                top--;
            }
            else Console.WriteLine("Underflow");
        }
        public void peak()
        {
            Console.WriteLine("Peak element is {0}", sal[top]);
        }
        public void display()
        {
            for (int i = top; i >= 0; i--)
            {
                Console.WriteLine(sal[i]);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            stacck s = new stacck();
            int ch;
            while (true)
            {
                Console.WriteLine("**Menu*");
                Console.WriteLine("1.Push");
                Console.WriteLine("2.Pop");
                Console.WriteLine("3.Peak");
                Console.WriteLine("4.Display");
                Console.WriteLine("5.Exit");
                ch = Convert.ToInt16(Console.ReadLine());
                if (ch == 1) s.push();
                if (ch == 2) s.pop();
                if (ch == 3) s.peak();
                if (ch == 4) s.display();
                if (ch == 5) break;
            }
        }
    }
}
