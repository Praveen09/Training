﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] i = new int[5];
            try
            {
                for (int j = 0; j <= 6; j++)
                {
                    i[j] = j+1;
                    Console.WriteLine(i[j]);
                }
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
