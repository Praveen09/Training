﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloading
{
    public class complex
    {
        public int r, i;
        public override string ToString()
        {
            return r.ToString() + "+" + i.ToString() + "i";
        }
        public static complex operator*(complex c1, complex c2)
        { 
        c1.r=c1.r*c2.r;
        c1.i=c1.i*c2.i;
        return c1;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            complex c=new complex();
            complex mul = new complex();
            complex c1 = new complex();
            complex c2 = new complex();
            c1.r = 2;
            c1.i = 4;
            c2.r = 5;
            c2.i = 6;
            mul = c1 * c2;
            Console.WriteLine(mul.ToString());
        }
    }
}
