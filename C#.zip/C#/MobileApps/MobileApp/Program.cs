﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileApp
{
    class mobile
    {
        public string Modelno;
        public double Cost;
        public double tax = 0.14;
        public double discount = 0.33;
        public string status;
        public double modify(mobile m, double x)
        {
            Cost = x;
            return Cost;
        }
        public mobile add()
        {
            mobile m = new mobile();
            Console.WriteLine("Enter the mobile details\nEnter the model no");
            m.Modelno = Console.ReadLine();
            Console.WriteLine("\nEnter the cost");
            m.Cost = Convert.ToDouble(Console.ReadLine());
            m.status = "available";
            return m;
        }
        public void checkstatus(mobile n, string m)
        {
            if (n.Modelno == m && n.status == "available")
            {
                Console.WriteLine("Mobile available");
            }
            else
                Console.WriteLine("Mobile not available");
        }
        public void purchase(mobile n, string m)
        {
            checkstatus(n, m);
            if (n.status == "available")
            {
                n.status = "notavailable";
                n.Cost = (n.Cost + (n.tax * n.Cost));
                n.Cost = n.Cost - (n.Cost * n.discount);
                Console.WriteLine("Thank you for purchasing the mobile\n" + "Model\t" + n.Modelno + "tax=" + n.tax * 100 + "\nFinalPrice\t" + n.Cost);
            }
        }
        public void display()
        {
            Console.WriteLine(Modelno + "\t" + Cost);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            List<mobile> list_mob = new List<mobile>();
            mobile m = new mobile();
            int i; double price; string mno;
        a: Console.WriteLine("\n 1:Addnewmobile \n 2:Purchase \n 3:Checkstatus \n 4:Display \n 5:Modify \n 6:Exit\n\nEnter your choice ");
            i = Convert.ToInt16(Console.ReadLine());
            switch (i)
            {
                case 1: mobile mob = new mobile();
                    mob = mob.add();
                    list_mob.Add(mob);
                    goto a;
                case 2: Console.WriteLine("Enter the model no");
                    mno = Console.ReadLine();
                    foreach (mobile x in list_mob)
                    {
                        if (x.Modelno == mno)
                        {

                            x.purchase(x, mno);
                        }
                    }
                    goto a;
                case 3: Console.WriteLine("Enter the model no");
                    mno = Console.ReadLine();
                    foreach (mobile x in list_mob)
                    {
                        if (x.Modelno == mno)
                        {
                            x.checkstatus(x, mno);
                        }
                    } goto a;
                case 4:
                    Console.WriteLine("List of Mobiles\n");
                    foreach (mobile x in list_mob)
                    {
                        if (x.status == "available")
                        { x.display(); }
                    }
                    goto a;
                case 5: Console.WriteLine("Enter the model no");
                    m.Modelno = Console.ReadLine();
                    foreach (mobile x in list_mob)
                    {
                        if (m.Modelno == x.Modelno)
                        {
                            Console.WriteLine("Enter the new price to be modifed");
                            price = Convert.ToDouble(Console.ReadLine());
                            x.Cost = price;

                        }

                    }
                    goto a;
                case 6: break;
                default: Console.WriteLine("Enter Correct Choice");
                    goto a;
            }
        }
    }
}