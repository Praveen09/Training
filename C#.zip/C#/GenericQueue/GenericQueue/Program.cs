﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericQueue
{
    class queue<T>
    {
        public T[] arr = new T[10];
        public T ch;
        public int size = 10;
        public int f = 0, r = -1, i;
        public void insert(T x)
        {
            if (r >= size - 1)
            {
                Console.WriteLine("Queue is full");
            }
            else
            {
                r++;
                arr[r] = x;
            }
        }
        public void delete()
        {

            if (f > r)
            {
                Console.WriteLine("Queue empty no elelment to be delelted");
            }
            else
            {
                Console.WriteLine("Element deleted is {0}", arr[f]);
                f++;
            }
        }
        public void display()
        {
            for (i = f; i <= r; i++)
            { Console.WriteLine(arr[i]); }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            queue<int> q = new queue<int>();

        a: Console.WriteLine("1:Insert 2:Delete 3:Display 4:Exit\n Enter your choice");
            i = Convert.ToInt16(Console.ReadLine());

            while (i != 4)
            {
                switch (i)
                {
                    case 1: Console.WriteLine("Enter the number");
                        q.ch = Convert.ToInt32(Console.ReadLine());
                        q.insert(q.ch);
                        goto a;
                    case 2: q.delete();
                        goto a;
                    case 3: q.display();
                        goto a;
                    case 4: break;
                    default: Console.WriteLine("Enter the correct choice");
                        goto a;
                }

            }
        }
    }
}
