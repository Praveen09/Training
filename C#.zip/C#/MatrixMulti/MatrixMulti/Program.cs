﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixMulti
{
    class matrix
    {

        public int m, n;
        public int[,] mat;
        public static matrix operator *(matrix m1, matrix m2)
        {
            matrix m4 = new matrix();
            m4.m = m1.m;
            m4.n = m2.n;
            m4.mat = new int[m1.m, m2.n];

            for (int i = 0; i < m1.m; i++)
            {
                for (int j = 0; j < m2.n; j++)
                {
                    m4.mat[i, j] = 0;
                    for (int k = 0; k < m2.n; k++)
                    {
                        m4.mat[i, j] += m1.mat[i, k] * m2.mat[k, j];
                    }
                }
            }
            return m4;
        }





    }

    class Program
    {
        static void Main(string[] args)
        {

            matrix m1 = new matrix();
            matrix m2 = new matrix();
            matrix m3 = new matrix();
            Console.WriteLine("enter the first matrix size");
            m1.m = Convert.ToInt16(Console.ReadLine());
            m1.n = Convert.ToInt16(Console.ReadLine());
            m1.mat = new int[m1.m, m1.n];
            Console.WriteLine("enter the second matrix size");
            m2.m = Convert.ToInt16(Console.ReadLine());
            m2.n = Convert.ToInt16(Console.ReadLine());
            m2.mat = new int[m2.m, m2.n];
            if (m1.n == m2.m)
            {
                m3.m = m1.m;
                m3.n = m2.n;
                Console.WriteLine("enter the first matrix");
                for (int i = 0; i < m1.m; i++)
                {
                    for (int j = 0; j < m1.n; j++)
                    {
                        m1.mat[i, j] = Convert.ToInt16(Console.ReadLine());
                    }
                }
                Console.WriteLine("enter the second matrix");
                for (int i = 0; i < m2.m; i++)
                {
                    for (int j = 0; j < m2.n; j++)
                    {
                        m2.mat[i, j] = Convert.ToInt16(Console.ReadLine());
                    }
                }

                m3.mat = new int[m1.m, m2.n];
                m3 = m1 * m2;

                Console.WriteLine("\nfirst matrix");
                for (int p = 0; p < m1.m; p++)
                {
                    for (int q = 0; q < m1.n; q++)
                    {
                        Console.Write(m1.mat[p, q] + "\t");
                        
                    }
                    Console.Write("\n");
                    
                }
                Console.WriteLine("\nsecond matrix");
                for (int p = 0; p < m2.m; p++)
                {
                    for (int q = 0; q < m2.n; q++)
                    {
                        Console.Write(m2.mat[p, q] + "\t");
                        
                    }
                    Console.Write("\n");
                    
                }
                Console.WriteLine("\nthird matrix");
                for (int p = 0; p < m3.m; p++)
                {
                    for (int q = 0; q < m3.n; q++)
                    {
                        Console.Write(m3.mat[p, q] + "\t");
                        
                    }
                    Console.Write("\n");
                    
                }
            }
            else 
            { 
                Console.WriteLine("matrix multiplication not possible"); 
            }
        }
    }
}

