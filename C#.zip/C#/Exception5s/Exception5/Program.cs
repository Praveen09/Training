﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception5
{
    public class rev
    {
        public void reverse(string s)
        {
            Console.WriteLine(s.ToUpper());
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            rev r = new rev();
            Console.WriteLine("Enter any String");
            string str = Console.ReadLine();
            try
            {
                if (str == string.Empty)
                {
                    throw new ArgumentNullException();
                }
                else r.reverse(str);
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
