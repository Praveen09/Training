﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee2
{
    class employee
    {
        public int id, sal;
        public string name;
        public int modify()
        {
            sal = sal + (sal * 10 / 100);

            return sal;

        }

        public override string ToString()
        {
            return "Id=" + id.ToString() + "\tSalary=" + sal.ToString() + "\n";
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            int ch, high = 0, shigh = 0;
            List<employee> list_emp = new List<employee>();
        a: Console.WriteLine("1:Add 2:Display 3:Modify 4:exit");
            ch = Convert.ToInt16(Console.ReadLine());
            switch (ch)
            {
                case 1: employee e = new employee();
                    Console.WriteLine("enter the employee id\n");
                    e.id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("enter the employee sal\n");
                    e.sal = Convert.ToInt32(Console.ReadLine());
                    list_emp.Add(e);

                    goto a;
                case 2: foreach (employee x in list_emp)
                    {
                        Console.WriteLine(x.ToString());
                    }
                    goto a;
                case 3: goto b;
                case 4: break;
                default: Console.WriteLine("Enter correct choice");
                    goto a;
            }
        b: foreach (employee x in list_emp)
            {
                if (high < x.sal)
                {
                    high = x.sal;
                }
            }
            foreach (employee x in list_emp)
            {
                if (x.sal > shigh && x.sal < high)
                {
                    shigh = x.sal;
                }
            }

            Console.WriteLine("highest sal is {0} and second highest is{1}", high, shigh);


            foreach (employee y in list_emp)
            {
                Console.WriteLine("before modification\n" + y.ToString());
                if (y.sal != high && y.sal != shigh)
                {
                    y.modify();
                }
                Console.WriteLine("after modification\n" + y.ToString());
            }
            goto a;
        c: Console.WriteLine();

        }

    }
}





