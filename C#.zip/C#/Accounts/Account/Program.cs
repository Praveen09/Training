﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account
{
    public class acc
    {
        public int num;
        public double bal;
        public override string ToString()
        {
            return "Account no.="+num.ToString()+","+"Balance is "+bal.ToString();
        } 
    }
    class Program
    {
        static void Main(string[] args)
        {
            acc a1 = new acc();
            a1.num = 1234;
            a1.bal = 45554.00;
            acc a2 = new acc();
            a2.num = 78789;
            a2.bal = 6556546.00;
            acc a3 = new acc();
            a3.num = 87755;
            a3.bal = 7894.00;
            acc a4 = new acc();
            a4.num = 8978;
            a4.bal = 6056.00;
            acc a5 = new acc();
            a5.num = 5004;
            a5.bal = 4540.00;
            acc a6 = new acc();
            a6.num = 1001;
            a6.bal = 4589.00;
            Console.WriteLine(a1.ToString());
            Console.WriteLine(a2.ToString());
            Console.WriteLine(a3.ToString());
            Console.WriteLine(a4.ToString());
            Console.WriteLine(a5.ToString());
        }
    }
}
