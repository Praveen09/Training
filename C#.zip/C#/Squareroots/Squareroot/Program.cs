﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squareroot
{
    public class Sqrt
    {
        public int n;
        public double calculate(double num)
        {

            double m = 1;
            double c = 0;
            for (int d = 0; d < 50; c = c + m, d++)
                if (c * c > num)
                {
                    c = c - m;
                    m = m / 10;
                }

            return c;
        }
    }

    public class Program
    {
        public static void Main()
        {
            Sqrt s = new Sqrt();

            List<int> lsqrt = new List<int>();
            lsqrt.Add(1212);
            lsqrt.Add(1966);
            lsqrt.Add(1698);
            lsqrt.Add(1254);
            lsqrt.Add(1444);
            foreach (var x in lsqrt)
            {
                Console.WriteLine("Num={0},SquareRoot={1}", x, s.calculate(x));
            }


        }
    }

}
