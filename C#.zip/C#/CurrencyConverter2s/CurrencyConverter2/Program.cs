﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverter2
{
    static class currency
    {
        public static double r1 = 67.20, r2 = 71.09, e1 = 0.93, e2 = 1.06;
        public static double r2d(double u)
        {
            Console.WriteLine("Converted {0} rupee to dollar", u);
            return u / r1;
        }
        public static double r2e(double e)
        {
            Console.WriteLine("Converted {0} rupee to E.dollar", e);
            return e / r2;
        }
        public static double d2r(double d)
        {
            Console.WriteLine("Converted {0} dollar to rupee", d);
            return d * r1;
        }
        public static double d2e(double f)
        {
            Console.WriteLine("Converted {0} dollar to E.dollar", f);
            return f / e1;
        }
        public static double e2d(double k)
        {
            Console.WriteLine("Converted {0} E.dollar to dollar", k);
            return k * e2;
        }
        public static double e2r(double j)
        {
            Console.WriteLine("Converted {0} E.dollar to rupee ", j);
            return j * r2;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(currency.r2d(64.0));
            Console.WriteLine("\n");
            Console.WriteLine(currency.r2e(115.2));
            Console.WriteLine("\n");
            Console.WriteLine(currency.d2r(44.25));
            Console.WriteLine("\n");
            Console.WriteLine(currency.d2e(89.6));
            Console.WriteLine("\n");
            Console.WriteLine(currency.e2r(65.4));
            Console.WriteLine("\n");
            Console.WriteLine(currency.e2d(78.5));
        }
    }
}
