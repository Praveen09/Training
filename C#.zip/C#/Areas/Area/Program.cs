﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area
{
    public class shape
    {
        public double a;
        public void area(int s)
        {
            a = s * s;
            Console.WriteLine("Area of Square {0}sq.", a);
        }
        public void area(int l, int b)
        {
            a = l * b;
            Console.WriteLine("Area of Rectangle {0}sq.", a);
        }
        public void area(float bt, float h)
        {
            a = (bt * h) / 2;
            Console.WriteLine("Area of Triangle {0}sq.", a);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            shape s = new shape();
            s.area(4.5f, 5.5f);
            s.area(8);
            s.area(6, 7);
        }
    }
}
