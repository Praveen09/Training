﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                double d = Double.NaN;
                Math.Sign(d);
            }
            catch (ArithmeticException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
