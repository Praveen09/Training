﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception6
{
    class StackOverflowException : ApplicationException
    {
        public string Message { get { return "Stack Overflow!!! No Space remained in Stack for new element"; } }
    }
    class StackUnderflowException : ApplicationException
    {
        public string Message { get { return "Stack Underflow!!! No element is present in Stack"; } }
    }

    public class stacck
    {
        public int[] sal = new int[5];
        public int size = 5;
        public int top = -1;
        public void push()
        {
            int p;
            Console.WriteLine("Enter  a number \n");
            p = Convert.ToInt16(Console.ReadLine());
            try
            {
                if (top < size - 1)
                {
                    top++;
                    sal[top] = p;
                    Console.WriteLine("Added");
                }
                else throw new StackOverflowException();
            }
            catch (StackOverflowException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void pop()
        {
            try
            {
                if (top >= 0)
                {
                    Console.WriteLine("{0} is popped out", sal[top]);
                    top--;
                }
                else throw new StackUnderflowException();
            }
            catch (StackUnderflowException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void peak()
        {
            try
            {
                Console.WriteLine("Peak element is {0}", sal[top]);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void display()
        {
            Console.WriteLine("\n");
            try
            {
                if (top == -1)
                {
                    throw new Exception();
                }
                else
                {
                    for (int i = top; i >= 0; i--)
                    {
                        Console.WriteLine(sal[i]);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            stacck s = new stacck();

            int ch;

            while (true)
            {
                try
                {
                    Console.WriteLine("**Menu*");
                    Console.WriteLine("1.Push");
                    Console.WriteLine("2.Pop");
                    Console.WriteLine("3.Peak");
                    Console.WriteLine("4.Display");
                    Console.WriteLine("5.Exit");
                    ch = Convert.ToInt16(Console.ReadLine());
                    if (ch == 1) s.push();
                    if (ch == 2) s.pop();
                    if (ch == 3) s.peak();
                    if (ch == 4) s.display();
                    if (ch == 5) break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
