﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace book
{
    class book
    {
        public string btitle;
        public int bno, i, n = 5;
        public string author;
        public string status;
        public void issue(string s)
        {

            if (btitle == s)
            {
                if (status == "available")
                {
                    status = "notavailable";
                }
                else
                {
                    Console.WriteLine("Book not available");
                }

            }

        }
        public void returned(string s)
        {
            status = "available";
            Console.WriteLine("Book returned");      
        }
        public override string ToString()
        {
            return bno.ToString() + "\t" + author + "\t" + btitle + "\t" + status.ToString();
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            int i, n = 5, ch;

            string s;

            book[] list = new book[5]
            
            {
             new book(){btitle="My Words",bno=1,author="Anonymous1",status="available"},
             new book(){btitle="Thinking Machines",bno=2,author="Anonymous2",status="available"},
             new book(){btitle="Burning Childhood",bno=3,author="Anonymous3",status="available"},
             new book(){btitle="Right or Wrong",bno=4,author="Anonymous4",status="available"},
             new book(){btitle="Where is future?",bno=5,author="Anonymous5",status="available"},
            };


        a: Console.WriteLine("1:issue 2:return 3:display 4:exit\n Enter your choice");
            ch = Convert.ToInt16(Console.ReadLine());

            switch (ch)
            {
                case 1: Console.WriteLine("Enter book title");
                    s = Console.ReadLine();
                    for (i = 0; i < n; i++)
                    {
                        list[i].issue(s);
                        Console.WriteLine(list[i].ToString());
                    }
                    Console.WriteLine("Book issued");
                    goto a;


                case 2: Console.WriteLine("Enter the book title");
                    s = Console.ReadLine();
                    for (i = 0; i < n; i++)
                    {
                        if (list[i].btitle == s && list[i].status == "not available")
                        {
                            list[i].returned(s);
                        Console.WriteLine("Book returned");
                        }
                        else if (list[i].btitle == s && list[i].status == "available")
                        {
                            Console.WriteLine("error");
                        }

                    }

                    for (i = 0; i < n; i++) { Console.WriteLine(list[i].ToString()); }
                    goto a;


                case 3: for (i = 0; i < n; i++)
                    {

                        Console.WriteLine(list[i].ToString());
                    }
                    goto a;

                case 4: break;
                default: Console.WriteLine("Enter correct choice");
                    break;

            }
        }
    }
}




