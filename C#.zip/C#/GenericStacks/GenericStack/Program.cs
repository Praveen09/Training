﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericStack
{
    class stack<T>
    {
        public T[] sal = new T[10];
        public T ch;
        public int size = 10;
        public int top = -1;
        public void push(T x)
        {
            if (top < size - 1)
            {
                top++;
                sal[top] = x;
            }
            else
            {
                Console.WriteLine("stack overflow");
            }
        }
        public void pop()
        {
            if (top > -1)
            {
                Console.WriteLine("{0} is popped out", sal[top]);
                top--;
            }
            else if (top == -1)
            {
                Console.WriteLine("stack underflow");
            }

        }
        public void display()
        {
            int temp = top;
            while (temp > -1)
            {
                Console.WriteLine(sal[temp]);
                temp--;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            stack<int> s = new stack<int>();

        a: Console.WriteLine("1:Push 2:Pop 3:Display 4:Exit\n Enter your choice");
            i = Convert.ToInt16(Console.ReadLine());

            while (i != 4)
            {
                switch (i)
                {
                    case 1: Console.WriteLine("Enter the number");
                        s.ch = Convert.ToInt32(Console.ReadLine());
                        s.push(s.ch);
                        goto a;
                    case 2: s.pop();
                        goto a;
                    case 3: s.display();
                        goto a;
                    case 4: break;
                    default: Console.WriteLine("Enter the correct choice");
                        goto a;
                }

            }
        }
    }
}
