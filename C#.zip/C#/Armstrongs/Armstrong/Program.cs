﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Armstrong
{
    class Program
    {
        static void Main(string[] args)
        {
            int  r, s = 0, k;
            Console.WriteLine("Enter a number to check whether it is a n armstrong number or not:");
            int a = Convert.ToInt16(Console.ReadLine());
            k = a;
            while (k > 0)
            {
                
                r = k % 10;
                s = s + (r * r * r);
                k = k / 10;
            }
                if (s == a)
                {
                    Console.WriteLine("ArmStrong");
                }
                else
                {
                    Console.WriteLine("Not an ArmStrong");
                }
            
        }
    }
}
