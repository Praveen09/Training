﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberofObjects
{
   public class test
    {
        public static int a = 0;
        public int count()
    {
        a = a + 1;
        return a;
    }
    }
    class Program
    {
        static void Main(string[] args)
        {
            

            test obj1 = new test();
            obj1.count();
            test obj2 = new test();
            obj2.count();
            test obj3 = new test();
            obj3.count();
            Console.WriteLine(test.a);
        }
    }
}
