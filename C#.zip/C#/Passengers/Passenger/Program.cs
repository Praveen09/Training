﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Passenger
{
    class Passengr
    {
        public long Pnr { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public void display()
        {
            Console.WriteLine("Passenger having pnr {0} travelled from {1} to {2}", Pnr, From, To);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Passengr p = new Passengr();
            p.Pnr = 4578945665;
            p.From = "Hyderabad";
            p.To = "Bengaluru";
            p.display();
        }
    }
}
