﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point
{
    class Point1<T>
    {
        public T z;
        public T X1; //{ get; set; }
        public T X2; //{ get; set; }
        public T Y1; //{get; set; }
        public T Y2;// {get; set; }
        public void calculate()
        {
            z = Math.Sqrt(Math.Pow(X2 - X1, 2) + (Math.Pow(Y2 - Y1, 2)));
            Console.WriteLine(z);
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Point<double> p = new Point1<double>();
            p.X1 = 3;
            p.X2 = 4;
            p.Y1 = 5;
            p.Y2 = 6;
            p.calculate();
        }
    }
}
