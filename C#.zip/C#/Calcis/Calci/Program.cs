﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calci
{
    public class Calculate
    {
        public void add()
        {
            Console.WriteLine("Enter 2 numbers to add:");
            int x, y;
            x = Convert.ToInt16(Console.ReadLine());
            y = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("sum of {0} and {1} is{2}",x,y,x + y);
        }
        public void sub()
        {
            Console.WriteLine("Enter 2 numbers to subtract:");
            int x, y;
            x = Convert.ToInt16(Console.ReadLine());
            y = Convert.ToInt16(Console.ReadLine());
            if(x<y)
            {
            Console.WriteLine("difference of {0} and {1} is {2} ",y,x,y-x);
            }
            else Console.WriteLine("difference of {0} and {1} is {2} ", x,y, x - y);
        }
        public void mul()
        {
            Console.WriteLine("Enter 2 numbers to multiply:");
            int x, y;
            x = Convert.ToInt16(Console.ReadLine());
            y = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("product of {0} and {1} is {2}",x,y,x * y);
        }
        public void div()
        {
            Console.WriteLine("Enter 2 numbers to divide:");
            double x, y;
            x = Convert.ToInt16(Console.ReadLine());
            y = Convert.ToInt16(Console.ReadLine());
            if(y>0) Console.WriteLine(x / y);
        }
             public void per()
        {
            Console.WriteLine("Enter 2 numbers to get how much % 1st is to 2nd :");
            double x, y;
            x = Convert.ToInt16(Console.ReadLine());
            y = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("{0}%",(x/y)*100);
        }

        }
    
    class Program
    {
        static void Main(string[] args)
        {
            Calculate c = new Calculate();
            while (true)
            {
                Console.WriteLine("**Calculator**");
                Console.WriteLine("1.Addition");
                Console.WriteLine("2.Subtraction");
                Console.WriteLine("3.Multiplication");
                Console.WriteLine("4.Division");
                Console.WriteLine("5.Percentage");
                Console.WriteLine("6.Exit");
                int ch = Convert.ToInt16(Console.ReadLine());
                if (ch == 1)
                {
                    c.add();
                }
                if (ch == 2)
                {
                    c.sub();
                }
                if (ch == 3)
                {
                    c.mul();
                }
                if (ch == 4)
                {
                    c.div();
                }
                if (ch == 5)
                {
                    c.per();
                }
                if (ch == 6)
                {
                    break;
                }
            
            }
        }
    }
}
