﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompoundInterest
{
    public class Loan
    {
        double p, r, t, a, c, s;
        public Loan(double g, double h, double i)
        {
            p = g; r = h; t = i;
        }
        public void SI()
        {
            s = p * r * t / 100;
            Console.WriteLine("Simple Interest is {0}", s);
        }
        public void CI()
        {
            a = p * Math.Pow(1 + (r / 100), t);
            c = a - p;
            Console.WriteLine("Compound Interest is {0}", c);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Loan l = new Loan(1000,2,8);
            l.SI();
            l.CI();
       }
    }
}
