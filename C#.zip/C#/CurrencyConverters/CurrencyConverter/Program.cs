﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverter
{
    public class Currency
    {
        public void rupee(int p)
        {
            double r1, r2;
            r1=p/67.20;
            r2=p/72.17;
            Console.WriteLine("\n{0} Rupee = {1} Dollar",p,r1);
            Console.WriteLine("{0} Rupee = {1} E.Dollar\n",p,r2);
        }
        public void dollar(int q)
        {
            double r1, r2;
            r1 = q * 67.20;
            r2 = q / 0.93;
            Console.WriteLine("\n{0} Dollar = {1} Rupee", q, r1);
            Console.WriteLine("{0} Dollar = {1} E.Dollar\n", q, r2);
        }
        public void edollar(int r)
        {
            double r1, r2;
            r1 = r *72.19;
            r2 = r *1.073;
            Console.WriteLine("\n{0} E.Dollar = {1} Rupee", r, r1);
            Console.WriteLine("{0} E.Dollar = {1} Dollar\n", r, r2);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int r;
            Currency c = new Currency();
            while (true)
            {
                Console.WriteLine("**Currency converter*");
                Console.WriteLine("1.Convert rupee");
                Console.WriteLine("2.Convert usd");
                Console.WriteLine("3.Convert eud");
                Console.WriteLine("4.Exit");
                int ch = Convert.ToInt16(Console.ReadLine());
                if (ch == 1)
                {
                    Console.WriteLine("Enter Rupee to get converted:");
                    r = Convert.ToInt16(Console.ReadLine());
                    c.rupee(r);
                }
                if (ch == 2)
                {
                    Console.WriteLine("Enter Dollar to get converted:");
                    r = Convert.ToInt16(Console.ReadLine());
                    c.dollar(r);
                }
                if (ch == 3)
                {
                    Console.WriteLine("Enter E.Dollar to get converted:");
                     r = Convert.ToInt16(Console.ReadLine());
                    c.edollar(r);
                }
                if (ch == 4)
                {
                    break;
                }
            }
        }
    }
}
