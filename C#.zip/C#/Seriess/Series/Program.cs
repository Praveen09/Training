﻿using System;
class Series
{
    public void display(int p, int q)
    {
        int z;
        Console.WriteLine("Square number series:");
        for (int i = p; i <= q; i++)
        {
            z = i * i;

            Console.WriteLine(z);
        }
    }
    public void display(int y)
    {
        int m = 0, n = 1, p = 0;
        Console.WriteLine("Fabonacci series:");
        Console.WriteLine(m + "\n" + n);
        for (int z = 0; z < y; z++)
        {

            p = m + n;
            Console.WriteLine(p);
            m = n;
            n = p;

        }
    }
    public void display(float low, float high)
    {
        int flag, i;
        Console.WriteLine("Prime no. series:");
        while (low < high)
        {
            flag = 0;

            for (i = 2; i <= low / 2; ++i)
            {
                if (low % i == 0)
                {
                    flag = 1;
                    break;
                }
            }

            if (flag == 0)

                Console.WriteLine(low);

            ++low;
        }

    }
}
public class Program
{
    public static void Main(string[] args)
    {
        Series s = new Series();
        int ch;
        while (true)
        {
            Console.WriteLine("**Menu*");
            Console.WriteLine("1. Squares");
            Console.WriteLine("2. Fabonacci");
            Console.WriteLine("3. Prime");
            Console.WriteLine("4.Exit");
            ch = Convert.ToInt16(Console.ReadLine());
            if (ch == 1)
            {
                Console.WriteLine("Enter a range to get squares");
                int x = Convert.ToInt16(Console.ReadLine());
                int y = Convert.ToInt16(Console.ReadLine());
                s.display(x, y);
            }
            if (ch == 2)
            {
                Console.WriteLine("Enter a number till which series needed");
                int x = Convert.ToInt16(Console.ReadLine());
                s.display(x);
            }
            if (ch == 3)
            {
                Console.WriteLine("Enter a range to get Prime numbers");
                float x = Convert.ToInt16(Console.ReadLine());
                float y = Convert.ToInt16(Console.ReadLine());
                s.display(x, y);
            }
            if (ch == 4)
            {
                break;
            }
        }
    }
}