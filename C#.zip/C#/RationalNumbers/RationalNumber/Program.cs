﻿using System;
namespace RationalNumbers
{
    class rational
    {
        public int p, q;
        public void display()
        {

            Console.WriteLine("Answer is {0}/{1}", p, q);
        }
    }
    class math
    {
        private int c, d, e;
        rational r3 = new rational();
        public rational add(rational c1, rational c2)
        {

            c = c2.q * c1.p;

            d = c1.q * c2.p;

            r3.p = c + d;

            r3.q = c1.q * c2.q;

            return r3;
        }
        public rational simplify(int c, int d)
        {

            int i = 2, t1, t2;
            t1 = c; t2 = d;
            while (t1 > 1 && i <= t1)
            {
                if (((t1 % i) == 0) && ((t2 % i) == 0))
                {
                    t1 = t1 / i;
                    t2 = t2 / i;
                }
                else i++;
                r3.p = t1; r3.q = t2;
            }


            return r3;
        }

    }

    public class program
    {
        public static void Main(string[] args)
        {
            rational r1 = new rational();
            r1.p = 6; r1.q = 12;
            rational r2 = new rational();
            r2.p = 3; r2.q = 12;
            rational r3 = new rational();
            math m1 = new math();
            r3 = m1.add(r1, r2);
            r3 = m1.simplify(r3.p, r3.q);
            Console.WriteLine("first rational number is {0}/{1}", r1.p, r1.q);
            Console.WriteLine("Second rational number is {0}/{1}", r2.p, r2.q);
            r3.display();
        }
    }
}

