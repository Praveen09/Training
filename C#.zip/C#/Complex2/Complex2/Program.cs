﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complex2
{
    public class Complex
    {
        public int r1,r2,i1,i2,z1,z2,a1,a2,b1,b2;double c1,c2;
        
        public override string ToString()
        {
            z1 = r1 + r2;
            z2 = i1 + i2;
            a1 = r1 - r2;
            a2 = i1 - i2;
            b1 = r1 * r2;
            b2 = i1 * i2;
            c1 = r1 / r2;
            c2 = i1 / i2;
            return "Addition is " + z1.ToString() + "+" + z2.ToString()+"i"+"\n"+
            "Subtraction is " + a1.ToString() + "+" + a2.ToString()+"i"+"\n"+
            "Multiplication is " + b1.ToString() + "+" + b2.ToString()+"i"+"\n"+
            "Division is " + c1.ToString() + "+" + c2.ToString()+"i";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Complex c = new Complex();
            c.r1 = 7;
            c.i1 = 20;
            c.r2 = 10;
            c.i2 = 9;
            Console.WriteLine(c.ToString());
        }
    }
}
