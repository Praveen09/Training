﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complex3
{
    class Complex
    {
        public int I { get; set; }
        public int R { get; set; }
        public Complex add(Complex c1, Complex c2)
        {
            c1.R = c1.R + c2.R;
            c1.I = c1.I + c2.I;
            return c1;
        }
        public override string ToString()
        {
            return R.ToString()+"+"+I.ToString()+"i";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Complex c = new Complex();
            Complex s = new Complex();
            Complex c1 = new Complex();
            Complex c2 = new Complex();
            c1.R = 1;
            c1.I = 2;
            c2.R = 3;
            c2.I = 4;
            s = c.add(c1, c2);
            Console.WriteLine(s.ToString());
        }
    }
}
