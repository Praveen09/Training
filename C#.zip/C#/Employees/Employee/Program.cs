﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class emp
    {
        public int id;
        public int sal;
        public override string ToString()
        {
            return sal.ToString();
        }
    }
    public class sort
    {
        int i, j, n = 5, temp;
        public int[] cal(int[] s)
        {
            for (i = 0; i < n; i++)
                for (j = 0; j < n - 1; j++)
                {
                    if (s[j] > s[j + 1])
                    {
                        temp = s[j + 1];
                        s[j + 1] = s[j];
                        s[j] = temp;
                    }
                }
            return s;
        }
        class Program
        {
            static void Main(string[] args)
            {
                int i, j;
                emp[] list = new emp[5];
                int[] salary = new int[5];
                for (i = 0; i < 5; i++)
                {
                    list[i] = new emp();
                    Console.WriteLine("Enter the {0} id, salary", i + 1);
                    list[i].id = Convert.ToInt16(Console.ReadLine());
                    list[i].sal = Convert.ToInt16(Console.ReadLine());
                    salary[i] = list[i].sal;
                }
                sort s = new sort();
                s.cal(salary);
                for (j = 0; j < 5; j++)
                {
                    list[j].sal = salary[j];
                }
                Console.WriteLine("Sorted salary is:-");
                for (i = 0; i < 5; i++)
                {
                    Console.WriteLine("{0}", list[i].ToString());
                }
                Console.WriteLine("The highest salary is {0}", list[i].sal);
            }
        }
    }
}

