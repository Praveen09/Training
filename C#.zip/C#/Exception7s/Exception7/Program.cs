﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception7
{
    class QueueFullException : ApplicationException
    {
        public string Message { get { return "Queue is Full!!!"; } }
    }
    class QueueEmptyException : ApplicationException
    {
        public string Message { get { return "Queue is Empty!!!"; } }
    }
    class queue
    {
        public int[] sal = new int[5];
        public int size = 5;
        public int f = 0, r = -1, i;
        public void insert(int x)
        {
            try
            {
                if (r >= size - 1)
                {
                    throw new QueueFullException();
                }
                else r++; sal[r] = x;
            }
            catch (QueueFullException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void delete()
        {
            try
            {
                if (f <= r)
                {
                    Console.WriteLine("{0} Element deleted ", sal[f]); f++;
                }
                else throw new QueueEmptyException();
            }
            catch (QueueEmptyException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void display()
        {
            for (i = f; i <= r; i++)
            {
                Console.WriteLine(sal[i]);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int ch, k;
            queue q = new queue();
            while (true)
            {
                try
                {
                a: Console.WriteLine("1:Insert 2:Delete 3:Display 4:Exit\n Enter your choice");
                    ch = Convert.ToInt16(Console.ReadLine());
                    switch (ch)
                    {
                        case 1: Console.WriteLine("Enter a no. to insert");
                            k = Convert.ToInt16(Console.ReadLine());
                            q.insert(k); goto a;
                        case 2: q.delete(); goto a;
                        case 3: q.display(); goto a;
                        case 4: break; 
                        default: Console.WriteLine("enter the correct choice"); goto a;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}

