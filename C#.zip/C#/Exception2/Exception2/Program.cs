﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception2
{
   
    class Program
    {
        static void Main(string[] args)
        {

            int[] i = new int[5]{1,2,3,4,5};
           
                try
                {
                    for (int j = 4; j >= 0; j--)
                    {
                        i[j] = i[j] / j;
                        Console.WriteLine(i[j]);
                    }
                }
                catch (DivideByZeroException m)
                {
                    Console.WriteLine(m.Message);
                }
        }
    }
}
