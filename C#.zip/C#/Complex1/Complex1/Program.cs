﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complex1
{
    public class Calculate
    {
        int r1, r2, i1, i2;double x,y;
        public void add()
        {
            Console.WriteLine("Enter 2 complex numbers to add:");
            
            r1 = Convert.ToInt16(Console.ReadLine());
            r2 = Convert.ToInt16(Console.ReadLine());
            i1 = Convert.ToInt16(Console.ReadLine());
            i2 = Convert.ToInt16(Console.ReadLine());
            x = r1 + r2;
            y = i1 + i2;
            Console.WriteLine("Addition is {0}+{1}i",x,y);
        }
        public void sub()
        {
            Console.WriteLine("Enter 2 complex numbers to subtract:");
            r1 = Convert.ToInt16(Console.ReadLine());
            r2 = Convert.ToInt16(Console.ReadLine());
            i1 = Convert.ToInt16(Console.ReadLine());
            i2 = Convert.ToInt16(Console.ReadLine());
            x = r1 - r2;
            y = i1 - i2;
            if (y < 0) Console.WriteLine("Substraction is {0}{1}i", x, y);
            else Console.WriteLine("subtraction is {0}+{1}i",x,y);
        }
        public void mul()
        {
            Console.WriteLine("Enter 2 complex numbers to multiply:");
            r1 = Convert.ToInt16(Console.ReadLine());
            r2 = Convert.ToInt16(Console.ReadLine());
            i1 = Convert.ToInt16(Console.ReadLine());
            i2 = Convert.ToInt16(Console.ReadLine());
            x = r1 * r2;
            y = i1 * i2;
            Console.WriteLine("Multiplication is {0}+{1}i", x, y);
        }
        public void div()
        {
            Console.WriteLine("Enter 2 complex numbers to divide:");
            r1 = Convert.ToInt16(Console.ReadLine());
            r2 = Convert.ToInt16(Console.ReadLine());
            i1 = Convert.ToInt16(Console.ReadLine());
            i2 = Convert.ToInt16(Console.ReadLine());
            x = r1 / r2;
            y = i1 / i2;
            Console.WriteLine("Division is {0}+{1}i", x, y);
        }
      }

    class Program
    {
        static void Main(string[] args)
        {
            Calculate c = new Calculate();
            while (true)
            {
                Console.WriteLine("**Calculator**");
                Console.WriteLine("1.Addition");
                Console.WriteLine("2.Subtraction");
                Console.WriteLine("3.Multiplication");
                Console.WriteLine("4.Division");
                   Console.WriteLine("5.Exit");
                int ch = Convert.ToInt16(Console.ReadLine());
                if (ch == 1)
                {
                    c.add();
                }
                if (ch == 2)
                {
                    c.sub();
                }
                if (ch == 3)
                {
                    c.mul();
                }
                if (ch == 4)
                {
                    c.div();
                }
                if (ch == 5)
                {
                    break;
                }

            }
        }
    }
}
