﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account2
{
    public class acc
    {
        public double num, bal;
        long i;
        public void withdraw()
        {
            Console.WriteLine("Enter money to withdraw");
            i = Convert.ToInt64(Console.ReadLine());
                bal = bal - i;
                Console.WriteLine("{0}Rs. deducted from Account no. {1}", i, num);
            
        }
        public override string ToString()
        {
            return "Account No.: "+num+" ,Balance: "+bal;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            
            acc[] a = new acc[5]
            {
            new acc() {num=1001,bal=55230.25},
            new acc() {num=1002,bal=34350.25},
            new acc() {num=1003,bal=6750.25},
            new acc() {num=1004,bal=4350.25},
            new acc() {num=1005,bal=5150.25},
            };
            Console.WriteLine("Transaction List");
            for (int i = 0; i < a.Length; i++)
            {
            
            Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("\nEnter Account No. to withdraw money");
            double x = Convert.ToInt16(Console.ReadLine());
           
            for (int i = 0; i < a.Length; i++)
            {
                if (x == a[i].num)
                {
                   a[i].withdraw();
                }

            }
            Console.WriteLine("\nUpdated Transaction List");
            for (int i = 0; i < a.Length; i++)
            {
            
                Console.WriteLine(a[i].ToString());
            }          

        }
    }
}
