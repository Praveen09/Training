﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Math1
{
    public class Math
    {
        int x, y, z;
        public Math(int g, int h)
        {
            x = g; y = h;
            
        }
        public void add()
        {
            Console.WriteLine("Addition of given 2 numbers is  {0}", x + y);
        }
        public void sub()
        {
            Console.WriteLine("Subtraction of given 2 numbers is {0}", x - y);
        }
        public void mul()
        {
            Console.WriteLine("Multiplication of given 2 numbers is {0}", x * y);
        }
        public void div()
        {
            Console.WriteLine("Division of given 2 numbers is {0}", x / y);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Math m = new Math(12, 6);
            m.add();
            m.sub();
            m.mul();
            m.div();
        }
    }
}
