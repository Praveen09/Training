﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue
{
    class queue
    {
        public int[] sal = new int[10];
        public int size = 10;
        public int f = 0, r = -1, i;
        public void insert(int x)
        {
            if (r >= size - 1)
            {
                Console.WriteLine("Queue is full");
            }
            else r++; sal[r] = x;
        }
        public void delete()
        {
            if (f <= r)
            {
                Console.WriteLine("{0} Element deleted ", sal[f]); f++;
                
            }
            else Console.WriteLine("Queue is Empty");
        }
        public void display()
        {
            for (i = f; i <= r; i++)
            {
                Console.WriteLine(sal[i]);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int ch, k;
            queue q = new queue();
        a: Console.WriteLine("1:Insert 2:Delete 3:Display 4:Exit\n Enter your choice");
        ch = Convert.ToInt16(Console.ReadLine());
        switch (ch)
        { 
            case 1:Console.WriteLine("Enter a no. to insert");
            k=Convert.ToInt16(Console.ReadLine());
            q.insert(k);goto a;
            case 2:q.delete();goto a;
            case 3:q.display();goto a;
            case 4:break;
            default:Console.WriteLine("enter the correct choice");goto a;
        }
        }
    }
}
