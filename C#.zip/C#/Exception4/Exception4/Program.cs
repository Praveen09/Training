﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception4
{
    class square
    {
       
        public void sq(int q)
        {
            q = q * q;
            Console.WriteLine(q);
        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            square s = new square();
            int i;
            Console.WriteLine("Enter any number between 1-10");
            i=Convert.ToInt16(Console.ReadLine());
            try
            {
                if (i <= 0 || i > 10)
                {
                    throw new ArgumentOutOfRangeException();
                }
                else s.sq(i);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
