﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reverse
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 0;
            int res = 0;
            while (true)
            {
                Console.WriteLine("Enter no to be reversed");
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    int i = number;
                    while (i > 0)
                    {
                        res = (res*10) + i % 10 ;
                        i = i / 10;
                    }
                    Console.Clear();
                    Console.WriteLine($"The reverse of {number} is {res}");
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Error in typing! Please enter integers only");
                }
            }
            Console.ReadLine();
        }
    }
}
