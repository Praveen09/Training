﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeanMode
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, sum = 0;
            double standard_dev_sum = 0;
            Console.WriteLine("Enter the number of elements");
            num = Int32.Parse(Console.ReadLine());
            int[] arr = new int[num];
            Console.WriteLine("Enter the elements");
            for (int i = 0; i < num; i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
                sum = sum + arr[i];
                standard_dev_sum = standard_dev_sum + (arr[i] * arr[i]);
            }
            cal_mean(sum, num);
            cal_median(arr, num);
            cal_standard_dev(standard_dev_sum, num);
            Console.ReadLine();
        }

        public static void cal_mean(int sum, int n)
        {
            double mean;
            mean = sum / n;
            Console.WriteLine($"the mean is {mean}");
           
        }

        public static void cal_median(int[] arr, int n)
        {
            int mid = n / 2;
            if (n % 2 == 0)
            {
                Console.WriteLine($"the median is {arr[mid]} and {arr[mid + 1]}");
            }
            else
            {
                Console.WriteLine($"the median is {arr[mid]}");
            }

        }

        public static void cal_standard_dev(double sdsum, int n)
        {
            double v;
            double sd;
            v = sdsum / n;
            sd = Math.Sqrt(v);
            Console.WriteLine($"the standard deviation is { sd}");
        }
        
    }
}
