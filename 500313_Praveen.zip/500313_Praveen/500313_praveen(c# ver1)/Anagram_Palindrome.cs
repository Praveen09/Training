﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace Anagram_palindrome
{
    class Program
    {
        static SpeechSynthesizer reader = new SpeechSynthesizer();
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                reader.Speak("Welcome to Bhawana's Program");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Choose the operation you want to perform");
                reader.Speak("Choose the operation you want to perform");
                Console.WriteLine("1.Anagram\n2.Palindrome");
                int choice;
                int.TryParse(Console.ReadLine(),out choice);
                if (choice==0 && choice!=1 && choice!=2)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Incorrect choice!!! Please choose again");
                    reader.Speak("Incorrect choice!!! Please choose again");
                    continue;
                }
                else
                {
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Anagram");
                            anagram();
                            break;
                        case 2:
                            Console.WriteLine("Palindrome");
                            palindrome();
                            break;
                    }
                    Console.WriteLine("Press YES if you want to check the strings again..else enter NO");
                    reader.Speak("Press YES if you want to check the strings again..else enter NO");
                    string choose = Console.ReadLine().ToUpper();
                    if (choose == "YES")
                        continue;
                    else
                    {
                        reader.Speak("Thank you");
                        break;
                    }
                }
            }
        }

        private static void palindrome()
        {            
            Console.WriteLine("enter the string");
            reader.Speak("enter the string");
            string s = Console.ReadLine();
            string rev= new string(s.ToCharArray().Reverse().ToArray());
            if (rev == s)
            {
                Console.WriteLine("String is Palindrome ");
                reader.Speak("String is Palindrome ");
            }
            else
            {
                Console.WriteLine("String is not Palindrome ");
                reader.Speak("String is not Palindrome ");
            }
        }

        static void anagram()
        {           
            Console.WriteLine("enter the 1st string");
            reader.Speak("enter the 1st string");
            string word1 = Console.ReadLine();
            Console.WriteLine("enter the 2nd string");
            reader.Speak("enter the 2nd string");
            string word2 = Console.ReadLine();
            char[] char1 = word1.ToLower().ToCharArray();
            char[] char2 = word2.ToLower().ToCharArray();
            Array.Sort(char1);
            Array.Sort(char2);
            string NewWord1 = new string(char1);
            string NewWord2 = new string(char2);
            if (NewWord1 == NewWord2)
            {
                Console.WriteLine("Given words are anagram");
                reader.Speak("Given words are anagram");
            }
            else
            {
                Console.WriteLine("Given words are not anagram");
                reader.Speak("Given words are not anagram");
            }
        }
    }
}
