﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestUsingFD
{
    class Program
    {
        public static void Main(string[] args)
        {
            double principle=0, TimePeriod=0;
            Console.WriteLine("Enter the amount");
            principle = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the time period in months");
            TimePeriod = double.Parse(Console.ReadLine());
            double tot_amt=calc(principle,TimePeriod);
            Console.WriteLine($"The final amount for Rs.{principle} in {TimePeriod} month is {tot_amt}.");
            Console.ReadLine();
        }

        private static double calc(double principle, double timePeriod)
        {
            double intr = 0, res = 0;
            if (timePeriod<=1.5)
            {
                intr = 5;
                res=cal_interest(principle, timePeriod, intr);
            }
            else if (timePeriod <=6 && timePeriod>1.5)
            {
                intr = 5.50;
                res=cal_interest(principle, timePeriod, intr);
            }
            else if (timePeriod >6 && timePeriod<=12)
            {
                intr = 5.75;
                res=cal_interest(principle, timePeriod, intr);
            }
            else if (timePeriod >12 && timePeriod<=36)
            {
                intr = 6;
                res=cal_interest(principle, timePeriod, intr);
            }
            else if (timePeriod > 36)
            {
                intr = 5.50;
                res=cal_interest(principle, timePeriod, intr);
            }
            return res;
        }

        private static double cal_interest(double principle, double timePeriod, double intr)
        {
            double total_amount = (principle * timePeriod * intr)/100;
            return principle + total_amount;
        }
        
    }
}
