﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorials
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number upto which factorial to be found");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine($" ");
            for (int i = n; i > 0; i--)
            {
                int result = factorial(i);

                Console.WriteLine("{0,-15} {1,15}", i, result);
            }
            Console.ReadLine();

        }

        public static int factorial(int n)
        {
            for (int i = n - 1; i > 0; i--)
            {
                n = n * i;
            }
            return n;

        }
    }
}
