﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometry
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayMenu();
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Rectangle re = new Rectangle();
                    re.Setvalues();
                    re.Area();
                    break;
                case 2:
                    Triangle t = new Triangle();
                    t.Setvalues();
                    t.Area();
                    break;
            }
        }
 public static void DisplayMenu()
        {
            Console.WriteLine("Choose the option");
            
            Console.WriteLine(
                "1.Rectangle 2.Traingle");
        

        }
    }
}class Shape
{
    public double d;
    public double d1;
    public void Setvalues()
    {

        Console.WriteLine("Enter the first value");
        d= Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Enter the second value");
        d1 = Convert.ToDouble(Console.ReadLine());

    }

    public virtual void Area()
    { }

}
class Triangle : Shape
{
    public override void Area()
    {
        double area =   (d * d1)/2;
        Console.WriteLine("Area of triangle:"+area);
        Console.ReadLine();
    }
}
class Rectangle : Shape
{
    public override void Area()
    {
        double area = (d * d1);
        Console.WriteLine("Area of Rectangle:" + area);
        Console.ReadLine();
    }
}





