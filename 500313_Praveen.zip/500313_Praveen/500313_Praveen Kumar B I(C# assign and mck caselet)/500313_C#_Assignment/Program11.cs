﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NameSpace
{
    class Program
    {
        struct student
        {
            public int stid;
            public int phy;
            public int che;
            public int mat;
            public int bio;
            public int high;
            public int total;
        };
        static void Main(string[] args)
        {
            student[] st = new student[10];

            int choice;
            string confirm;
            int count = 0;
            Console.WriteLine("Enter Student Data");
            Console.WriteLine("1. ADD");
            Console.WriteLine("2. TotalMark");
            Console.WriteLine("3. HighestID");
            Console.WriteLine("4. HighestTotalMarks");
            Console.WriteLine("5. TotalinPCM");
            Console.WriteLine("6. DescPC85B");
            do
            {
                Console.Write("enter your choice(1-5):");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Add(st, count);
                        count++;
                        break;
                    case 2:
                       TotalMark(st);
                        break;
                    case 3:

                        HighestId(st);
                        break;
                    case 4:

                        HighestTotalMarks(st);
                        break;
                    case 5:
                       highinpcm(st);
                        break;
                    case 6:
                        Despcb(st);

                        break;
                    default:
                        Console.WriteLine("\nEnter b/w 1-4\n");
                        break;
                }
                Console.Write("Press Y or y to continue:");
                confirm = Console.ReadLine().ToString();
            } while (confirm == "Y" || confirm == "y");
        }
        static void Add(student[] st, int count)
        {
            Console.Write("\nEnter student ID: ");
            st[count].stid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student phy marks: ");
            st[count].phy = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student che marks: ");
            st[count].che = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student math marks: ");
            st[count].mat = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student Bio marks: ");
            st[count].bio = Convert.ToInt32(Console.ReadLine());
        }

        static void TotalMark(student[] st)
        {
            Console.Write("\nEnter student ID: ");
            int studid = Convert.ToInt32(Console.ReadLine());
            for (int count = 0; count < st.Length; count++)
            {
                if (studid == st[count].stid)
                {

                    int total = st[count].phy + st[count].che + st[count].mat + st[count].bio;
                    Console.WriteLine($"Total marks obtained by {st[count]} is {total}");

                }
            }
        }


        static void HighestId(student[] st)
        {
            int hm = 0;
            int chm = 0;
            int bhm = 0;
            int mhm = 0;
            for (int count = 0; count < st.Length; count++)
            {
                if (hm < st[count].phy)
                {
                    hm = st[count].phy;
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (hm == st[count].phy)
                {
                    Console.WriteLine($"The person who scored highest marks in physics is {st[count].stid}");
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (chm < st[count].che)
                {
                    chm = st[count].che;
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (chm == st[count].che)
                {
                    Console.WriteLine($"The person who scored highest marks in chemistry is {st[count].stid}");
                    
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (mhm < st[count].mat)
                {
                    mhm = st[count].mat;
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (mhm == st[count].mat)
                {
                    Console.WriteLine($"The person who scored highest marks in maths is {st[count].stid}");
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (bhm < st[count].bio)
                {
                    bhm = st[count].bio;
                }
            }
            for (int count = 0; count < st.Length; count++)
            {
                if (bhm == st[count].bio)
                {
                    Console.WriteLine($"The person who scored highest marks in biology is {st[count].stid}");
                }
            }

        }

        static void HighestTotalMarks(student[] st)
        {

            int max = 0;
            for (int count = 0; count < st.Length; count++)
            {

                st[count].high = st[count].phy + st[count].che + st[count].mat + st[count].bio;

            }

            for (int i = 0; i < st.Length; i++)
            {
                if (st[i].high > max)
                    max = st[i].high;

            }
            Console.WriteLine("highest marks" + max);
        }






        static void highinpcm(student[] st)
        {

            int temp = 0;
            for (int i = 0; i < st.Length; i++)
            {
                for (int j = i + 1; j < st.Length; j++)
                {
                    if (st[i].phy < st[j].phy)
                    {
                        temp = st[i].phy;
                        st[i].phy = st[j].phy;
                        st[j].phy = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in physics are {st[i].phy}");
            }

            for (int i = 0; i < st.Length; i++)
            {
                for (int j = i + 1; j < st.Length; j++)
                {
                    if (st[i].che < st[j].che)
                    {
                        temp = st[i].che;
                        st[i].che = st[j].che;
                        st[j].che = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in chemistry are {st[i].che}");
            }

            for (int i = 0; i < st.Length; i++)
            {
                for (int j = i + 1; j < st.Length; j++)
                {
                    if (st[i].mat < st[j].mat)
                    {
                        temp = st[i].mat;
                        st[i].mat = st[j].mat;
                        st[j].mat = temp;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"The top 5 students in maths are {st[i].mat}");
            }

        }

        static void Despcb(student[] st)
        {

            int temp = 0;

            for (int i = 0; i < st.Length; i++)
            {
                st[i].total = st[i].phy + st[i].che + st[i].bio;
            }
            for (int i = 0; i < st.Length; i++)
                for (int j = i + 1; j < st.Length; j++)
                {
                    if (st[i].total < st[j].total)
                    {
                        temp = st[i].total;
                        st[i].total = st[j].total;
                        st[j].total = temp;
                    }
                }
        
            for (int i = 0; i<st.Length; i++)
            {
                Console.WriteLine($"The total marks in descending order in physics chemistry and biology is {st[i].total}");
            }

        }

      }
}

