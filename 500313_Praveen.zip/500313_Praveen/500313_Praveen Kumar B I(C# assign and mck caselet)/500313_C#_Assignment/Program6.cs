﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FixedDeposit
{
    class Program
    {
        static void Main(string[] args)
        {
            
                double principal;
                double term;
                Console.WriteLine("enter the principal amount");
                principal = Double.Parse(Console.ReadLine());
                Console.WriteLine("enter the term of deposit in months");
                term = Double.Parse(Console.ReadLine());

                calculate(principal, term);
            }

        public static void calculate(double principal, double term)
        {
            double intrest;
            if (term <= 3)
            {
                intrest = 0.5;
                calinterest(principal, term, intrest);
            }
            else if ((term >= 3) && (term <= 6))
            {
                intrest = .55;
                calinterest(principal, term, intrest);

            }
            else if ((term >= 6) && (term <= 12))
            {
                intrest = .6;
                calinterest(principal, term, intrest);
            }
            else
            {
                intrest = .7;
                calinterest(principal, term, intrest);

            }
        }
        public static void calinterest(double principal, double term, double intrest)
        {
            double finalvalue = (principal * term * intrest) / 100;
            double sum;
            sum = principal + finalvalue;
            Console.WriteLine("the maturity amount of {0} for the period of {1} months is {2}", principal, term, sum);
            Console.ReadLine();

        }
    }
}
