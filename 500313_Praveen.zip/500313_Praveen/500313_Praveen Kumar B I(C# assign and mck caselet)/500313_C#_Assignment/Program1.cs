﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseNumber
{
    class Program
    {
        static void Main()
        {

            Console.WriteLine("Enter a Number");
            int num = int.Parse(Console.ReadLine());
            int reverse = 0;
            while (num > 0)
            {
                int rem = num % 10;
                reverse = (reverse * 10) + rem;
                num = num / 10;

            }
            Console.WriteLine("Reverse number={0}", reverse);
            Console.ReadLine();
        }

        }
}