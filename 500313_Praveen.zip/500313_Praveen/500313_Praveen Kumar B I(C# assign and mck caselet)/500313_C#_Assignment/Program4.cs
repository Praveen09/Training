﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciSum
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            Console.WriteLine(a);
            int b = 1;
            Console.WriteLine(b);
            
    
            for(int i=2;i<=10;i++)
            {
               int next = a + b;

                a = b;
                b = next;
                Console.WriteLine(next);
               // Console.ReadLine();
            }
            Console.ReadLine();
        }
    }
}
