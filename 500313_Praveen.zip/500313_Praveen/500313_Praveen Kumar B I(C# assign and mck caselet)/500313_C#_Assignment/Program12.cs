﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pallindrome
{
    class Program
    {
       static void Main(string[] args) { 

         string s, revs = "";
        Console.WriteLine(" Enter string");
            s = Console.ReadLine();
            for (int i = s.Length - 1; i >=0; i--) //String Reverse
            {
                revs += s[i].ToString();
    }
            if (revs == s) // Checking whether string is palindrome or not
            {
                Console.WriteLine("String is Palindrome ");
            }
            else
            {
                Console.WriteLine("String is not Palindrome ");
            }
            Console.ReadLine();
           Console.WriteLine( AreAnagram("silent","listen" ));
            Console.ReadLine();
        }
        static bool AreAnagram(string s1, string s2)
        {

            if (s1.Length != s2.Length)
                return false;

            foreach (char c in s1)
            {
                int ix = s2.IndexOf(c);

                if (ix == -1)
                    return false;
            }

            return true;
        }
    }
}