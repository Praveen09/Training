﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication10;


namespace caseletBanking
{

    interface Itransaction
    {
        void transferamount();
    }
    interface IROI
    {
        void getRateofInterest();
    }
    abstract class account
    {

        public  long accountno;
        public string username;
        public string typeofaccount;
        public double balance;
        public double roi;
        public void openaccount() { }
        public void closeaccount() { }
        public void editaccount() { }
        public void deposit() { }
        public void withdrawal() { }
        public void checkbalance() { }
        public string w = "";
        public account()
        {

            accountno = getrandom();

        }
        public long getrandom()
        {

            Random r = new Random();
            long ac_num = 0;

            for (int i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                ac_num = Convert.ToInt64(w);
            }
            return ac_num;

        }
    }
   

    class Program
    {
        static void Main(string[] args)
        {
            long ch, type;
            double amount;
            long account1;

            currentaccount f = new currentaccount();
            savingsaccount b = new savingsaccount();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome To MyBank");
        u: Console.WriteLine("1:current account \t 2: savings account \t 3: exit\n Enter your choice\n");
            try
            {
                type = Convert.ToInt16(Console.ReadLine());

                if (type == 1)
                {
                h: Console.WriteLine(" 1:Openaccount\n 2:Editaccount\n 3:Closeaccount\n 4:Getaccountdetails\n 5:Checkbalance\n 6:Deposit\n 7:Withdraw\n 8:Previousmenu\n 9:Transferamount\n10:GetRateofInterest\n11:Exit\nEnter Your Choice");
                    ch = Convert.ToInt16(Console.ReadLine());
                    switch (ch)
                    {
                        case 1:
                            f.openaccount();
                            goto h;
                        case 2:
                            Console.WriteLine("Enter the account number");
                            account1= Convert.ToInt64(Console.ReadLine());
                            f.Editaccount(account1);
                            goto h;
                        case 3:
                            Console.WriteLine("Enter the account number to be closed");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            f.closeaccount(account1);
                            goto h;
                        case 4:
                            f.getaccountdetails();
                            goto h;
                        case 5:
                            Console.WriteLine("Enter the account number\n");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            f.checkbalance(account1);
                            Console.ReadLine();
                            goto h;
                        case 6:
                            Console.WriteLine("Enter the account number\n");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("Enter the amount to be deposited\n");
                            amount = Convert.ToDouble(Console.ReadLine());
                            f.deposit(account1, amount);
                            goto h;
                        case 7:
                            
                            Console.WriteLine("Enter the account number\n");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("Enter the amount to be withdrawn\n");
                            amount = Convert.ToDouble(Console.ReadLine());
                            f.withdraw(account1, amount);
                           // Console.ReadLine();
                            goto h;
                        case 8: goto u;
                        case 9:
                            f.transferamount();
                            goto h;
                        case 10: f.getRateofInterest(); goto h;
                        case 11: break;
                        default:
                            Console.WriteLine("Enter the correct choice");
                            goto h;

                    }
                    Console.ReadLine();
                }
                if (type == 2)
                {


                c: Console.WriteLine(" 1:Openaccount\n 2:Editaccount\n 3:Closeaccount\n 4:Getaccountdetails\n 5:Checkbalance\n 6:Deposit\n 7:Withdraw\n 8:Previousmenu\n 9:Transfer amount\n 10:GetRateofInterest\n11:Exit\nEnter Your Choice");
                    ch = Convert.ToInt16(Console.ReadLine());
                    switch (ch)
                    {
                        case 1:
                            b.openaccount();
                            goto c;
                        case 2:
                            Console.WriteLine("Enter the account number");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            b.Editaccount(account1);
                            goto c;
                        case 3:
                            Console.WriteLine("Enter the account number to be closed");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            b.closeaccount(account1);
                            goto c;
                        case 4:
                            b.getaccountdetails();
                            goto c;

                        case 5:
                            Console.WriteLine("Enter the account number\n");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            b.checkbalance(account1);
                            goto c;
                        case 6:
                            Console.WriteLine("Enter the account number\n");
                            account1= Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("Enter the amount to be deposited\n");
                            amount = Convert.ToDouble(Console.ReadLine());
                            b.deposit(account1, amount);
                            goto c;
                        case 7:
                            Console.WriteLine("Enter the account number\n");
                            account1 = Convert.ToInt64(Console.ReadLine());
                            Console.WriteLine("Enter the amount to be withdrawn\n");
                            amount = double.Parse(Console.ReadLine());
                            b.withdraw(account1, amount);
                            goto c;
                        case 8: goto u;
                        case 9:
                            b.transferamount();
                            Console.ReadLine();
                            goto c;
                        case 10:
                            b.getRateofInterest();
                            goto c;
                        case 11: break;
                        default:
                            Console.WriteLine("Enter the correct choice");
                            goto c;

                    }
                }
                if (type == 3)
                {
                    Console.WriteLine("Thank you");
                }
            }
            catch (Exception u)
            {
                Console.WriteLine(u.Message);
            }
            Console.ReadLine();
        }
    }
}


