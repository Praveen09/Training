﻿using System;
using System.Collections.Generic;
using caseletBanking;

namespace ConsoleApplication10
{
    
    
        class savingsaccount : account, Itransaction, IROI
        {
            public double amount;
            public double MaxAmountPerDay = 20000;
            public string typeofaccount = "Savings account";
            static readonly long num = 28000; int i = 1;
            List<savingsaccount> register2 = new List<savingsaccount>();

            public void getaccountdetails()
            {
                bool temp = false;
                Console.WriteLine("The account holder details are \n");
                foreach (savingsaccount x in register2)
                {
                    temp = true;

                    Console.WriteLine("TypeofAccount:" + "\t" + x.typeofaccount);
                    Console.WriteLine("Account holder name:" + "\t" + x.username);
                    Console.WriteLine("Account number:\t" + "\t" + x.accountno);
                    Console.WriteLine("Available balance:" + "\t" + x.balance);

                }
                if (temp == false)
                {
                    Console.WriteLine("No account to be display");
                }
            }
            public void getRateofInterest()
            {
                Console.WriteLine("Enter the rate of Interest ");
                roi = Convert.ToDouble(Console.ReadLine());
            }

            public void openaccount()
            {
                savingsaccount s = new savingsaccount();
            a: Console.WriteLine("Enter the Accountholder name ");
                s.username = Console.ReadLine();
                Console.WriteLine("Enter the Amount to be deposited");
                amount = Convert.ToDouble(Console.ReadLine());
                if (amount < 1000)
                {
                    Console.WriteLine("Minimum amount to open an account is 1000");
                    goto a;
                }
                else
                {
                    s.balance = amount;
                    s.accountno = num + i++;
                    register2.Add(s);
                    Console.WriteLine("Congrats Your Account has been activated");
                    Console.WriteLine("your account number is" + s.accountno);

                }
            }

            public void closeaccount(long l)
            {
                bool temp = false;
                foreach (savingsaccount s in register2)
                {
                    if (s.accountno == l)
                    {
                        temp = true;
                        if (s.balance > 0)
                        {
                            Console.WriteLine("Account not empty");

                            return;
                        }
                        else if (s.balance == 0)
                        {
                            register2.Remove(s);
                            Console.WriteLine("Account deleted successfully");
                            return;
                        }
                    }
                }
                if (temp == false)
                {
                    Console.WriteLine("invalid account number");
                }

            }
            public void Editaccount(long acc)
            {
                bool temp = false;
                foreach (savingsaccount x in register2)
                {
                    if (x.accountno == acc)
                    {
                        temp = true;
                        Console.WriteLine("Enter the Accountholder name ");
                        x.username = Console.ReadLine();
                        Console.WriteLine("Account holder name is edited");
                    }
                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }
            }
            public void deposit(long acc, double d)
            {
                bool temp = false;
                foreach (savingsaccount x in register2)
                {
                    if (x.accountno == acc)
                    {

                        x.balance = x.balance + d;
                        temp = true;
                    }

                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }

            }
            public void withdraw(long acc, double d)
            {
                bool temp = false;
                foreach (savingsaccount x in register2)
                {
                    if (x.accountno == acc)
                    {
                        temp = true;
                        try
                        {
                            if ((x.balance - d) < 0)
                            {
                                throw new Exception("Amount cannot be withdrawn due to insufficient balance");
                            }
                            else
                            { x.balance = x.balance - d; }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }
                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }

            }
            public void checkbalance(long b)
            {
                bool temp = false;
                foreach (savingsaccount x in register2)
                {
                    if (x.accountno == b)
                    {
                        temp = true;
                        Console.WriteLine("Account balance:" + "\t" + x.balance);
                    }
                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }
                Console.ReadLine();


            }
            public void transferamount()
            {
                long fromaccount, toaccount;
                double amount; bool temp1 = false, temp2 = false;
                Console.WriteLine("Enter your account number");
                fromaccount = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the account number to whom the money has to be transferred ");
                toaccount = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the amount to be transferred");
                amount = Convert.ToDouble(Console.ReadLine());
                foreach (savingsaccount x in register2)
                {
                    if (x.accountno == fromaccount)
                    {

                        temp1 = true;
                        if (x.balance - amount >= 0)
                        {
                            foreach (savingsaccount y in register2)
                            {
                                if (y.accountno == toaccount)
                                {
                                    temp2 = true;
                                    x.balance = x.balance - amount;
                                    y.balance = y.balance + amount;
                                    Console.WriteLine("Amount transferred");
                                }

                            }
                            if (temp2 == false)
                            {
                                Console.WriteLine("Wrong account number");
                            }
                        }
                        else if (x.balance - amount < 0)
                        {
                            Console.WriteLine("Amount cannot be transferred due tu insuffient balance");
                        }
                        if (temp1 == false)
                        {
                            Console.WriteLine("Your account number is invalid");
                        }
                    }
                }

            }
        }
    }

