﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace operation_theatre
{
    public partial class Department : System.Web.UI.Page
    {
        string _connStr = @"Server=INCHCMPC08943;Database=OPERATION DATABASE;Trusted_Connection=True;";


        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        protected void Button4_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Department", con);
            SqlCommandBuilder Cmd = new SqlCommandBuilder(da);

            DataSet Ds4 = new DataSet();

            da.Fill(Ds4, "Department");
            GridView1.DataSource = Ds4.Tables[0];

            GridView1.DataBind();
            con.Close();
        }

        protected void Img_DeptHome_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Admin interface.aspx");
        
        }

        protected void Img_Deptlogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("loginDetails.aspx");
        }
    }
  }