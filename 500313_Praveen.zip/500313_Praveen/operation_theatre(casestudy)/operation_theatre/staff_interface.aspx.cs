﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace operation_theatre
{
    public partial class staff_interface : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[2] { new DataColumn("Id"), new DataColumn("Name") });
                dt.Rows.Add(1, "TheaQueen" );
                dt.Rows.Add(2, "SaraLance");
                dt.Rows.Add(3, "SaraHawl");
                dt.Rows.Add(4, "RoySebastian");
                dt.Rows.Add(4, "JohnnyBrown");
                dt.Rows.Add(4, "ChrisMathew");
                dt.Rows.Add(4, "LeoMathew");
                dt.Rows.Add(4, "MessiLionel");
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}